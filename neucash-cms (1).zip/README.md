# Neucash CMS (Strapi)

A beginner-friendly Strapi CMS for managing Brokers and Articles, styled with Neucash colors and deployable on Railway.

## Features
- PostgreSQL database (Railway-compatible)
- Brokers and Articles content types
- Admin panel with Neucash red (#B91C1C) and navy (#1E3A8A)
- API filtering support
- Optimized for Railway free tier

## Setup Guide
See full setup instructions in the accompanying documentation or at the root of this repo.
