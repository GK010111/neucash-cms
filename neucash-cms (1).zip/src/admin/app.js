export default {
  config: {
    theme: {
      colors: {
        primary100: '#FEE2E2',
        primary500: '#B91C1C',
        primary600: '#991B1B',
        primary700: '#7F1D1D',
        buttonPrimary500: '#1E3A8A',
      },
    },
  },
  bootstrap(app) {
    console.log(app);
  },
};
