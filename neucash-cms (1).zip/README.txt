# Instructions: Setting Up Neucash CMS (Strapi)

## Step 1: Create Project Folder

1. On your computer, create a new folder named `neucash-cms`.

## Step 2: Copy Project Files

2. Extract the contents of the provided ZIP file into the `neucash-cms` folder.
   - You can do this with a text/code editor like:
     - [VS Code (free)](https://code.visualstudio.com)
     - Notepad++ or similar.

3. Ensure the folder structure looks like this:

```
neucash-cms/
├── .env.example
├── README.txt
├── README.md
├── config/
│   ├── database.js
│   └── middleware.js
├── src/
│   ├── admin/
│   │   └── app.js
│   ├── api/
│   │   ├── article/
│   │   │   └── content-types/article/schema.json
│   │   └── broker/
│   │       └── content-types/broker/schema.json
```

## Step 3: Follow the Guide

Open the `README.md` file in a Markdown viewer/editor or follow the full setup guide provided with this project for:

- Local development setup
- GitHub setup
- Deployment to Railway
- Adding sample data
- Testing the API

## Support

Need help? Ask ChatGPT or visit the [Strapi Documentation](https://docs.strapi.io).
